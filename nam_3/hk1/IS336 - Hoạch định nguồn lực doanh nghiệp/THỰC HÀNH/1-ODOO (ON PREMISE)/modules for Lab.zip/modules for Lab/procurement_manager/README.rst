Procurement manager
===================
With this module, you can select multiple procurement orders and check, run,
cancel, and reset to confirmed them at once.

Credits
=======

Contributors
------------
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>