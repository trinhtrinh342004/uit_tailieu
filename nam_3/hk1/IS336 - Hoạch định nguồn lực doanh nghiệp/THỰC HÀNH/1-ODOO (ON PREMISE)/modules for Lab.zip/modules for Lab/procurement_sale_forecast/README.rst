MPS - Sale forecast
===================

This module allows to create a sale forecast
- New object to define a forecast by day, partner and products.
- New wizard to create procurements for products in forecast lines.
- New wizard on sale orders and budgets to load sale lines on budget.
