# -*- coding: utf-8 -*-
# (c) 2015 Alfredo de la Fuente - AvanzOSC
# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html
from . import wiz_import_procurement_from_plan
from . import wiz_change_procurement_date
from . import wiz_change_procurement_date_planned
from . import wiz_load_sale_from_plan
from . import wiz_load_purchase_from_plan
