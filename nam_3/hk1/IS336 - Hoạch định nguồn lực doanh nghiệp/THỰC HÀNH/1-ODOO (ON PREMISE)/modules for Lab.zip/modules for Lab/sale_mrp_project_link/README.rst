Sale - MRP Project Link
=======================

This module links sales, with a main project, when a product is defined as
"Make to Order".