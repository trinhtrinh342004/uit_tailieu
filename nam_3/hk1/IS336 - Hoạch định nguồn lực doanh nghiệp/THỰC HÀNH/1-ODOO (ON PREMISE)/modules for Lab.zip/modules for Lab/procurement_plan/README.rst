Procurement plan
================

This module creates the new object Procurement Plan. You can import
procurements before being treated from the plan. All Procurements and generated
purchases, be associated with the plan.

Also you can generate procurements for sale, and purchase forecast with buttons
"Load sales", and "Load purchases".

Credits
=======

Contributors
------------
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <ajuaristo@gmail.com>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
